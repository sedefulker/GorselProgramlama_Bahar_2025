namespace GorselProgramlamaOdev2;

public partial class ColorPickerPage : ContentPage
{
	public ColorPickerPage()
	{
		InitializeComponent();
		UpdateColor();
	}

	private void OnColorChanged(object sender, ValueChangedEventArgs e)
	{
		UpdateColor();
	}

	private void UpdateColor()
	{
		int red = (int)RedSlider.Value;
		int green = (int)GreenSlider.Value;
		int blue = (int)BlueSlider.Value;
		string hexColor = $"#{red:X2}{green:X2}{blue:X2}";

		RedLabel.Text = $"K�rm�z�: {red}";
		GreenLabel.Text = $"Ye�il: {green}";
		BlueLabel.Text = $"Mavi: {blue}";
		HexColorLabel.Text = hexColor;
		ColorDisplay.Color = Color.FromRgb(red, green, blue);
	}

	private async void OnCopyColorCode(object sender, EventArgs e)
	{
		await Clipboard.SetTextAsync(HexColorLabel.Text);
		await DisplayAlert("Kopyaland�", $"Renk kodu: {HexColorLabel.Text}", "Tamam");
	}

	private void OnRandomColor(object sender, EventArgs e)
	{
		Random random = new Random();
		RedSlider.Value = random.Next(0, 256);
		GreenSlider.Value = random.Next(0, 256);
		BlueSlider.Value = random.Next(0, 256);
		UpdateColor();
	}
}