namespace GorselProgramlamaOdev2;

public partial class BMICalculatorPage : ContentPage
{
	public BMICalculatorPage()
	{
		InitializeComponent();
		WeightSlider.Value = 70;
		HeightSlider.Value = 170;
	}

	private void OnWeightChanged(object sender, ValueChangedEventArgs e)
	{
		UpdateBMI();
	}

	private void OnHeightChanged(object sender, ValueChangedEventArgs e)
	{
		UpdateBMI();
	}

	private void UpdateBMI()
	{
		double weight = WeightSlider.Value;
		double height = HeightSlider.Value / 100; // cm to meters
		double bmi = weight / (height * height);
		BMIResultLabel.Text = $"VK�: {bmi:F2}";
	}
}