namespace GorselProgramlamaOdev2;

public partial class CreditPage : ContentPage
{
	public CreditPage()
	{
		InitializeComponent();
	}

	private void OnSliderValueChanged(object sender, ValueChangedEventArgs e)
	{
		DurationLabel.Text = $"Vade: {(int)e.NewValue} Ay";
	}

	private void OnCalculateClicked(object sender, EventArgs e)
	{
		try
		{
			double interestRate = double.Parse(InterestRateEntry.Text) / 100;
			double principalAmount = double.Parse(CreditAmountEntry.Text);
			int duration = (int)DurationSlider.Value;

			// �rnek oranlar
			double kkdf = 0.15, bsmv = 0.10;

			double monthlyRate = interestRate + (interestRate * kkdf) + (interestRate * bsmv);
			double installment = (Math.Pow(1 + monthlyRate, duration) * monthlyRate) /
								 (Math.Pow(1 + monthlyRate, duration) - 1) * principalAmount;

			ResultLabel.Text = $"Ayl�k Taksit: {installment:F2} TL";
		}
		catch (Exception)
		{
			DisplayAlert("Hata", "L�tfen t�m alanlar� doldurun.", "Tamam");
		}
	}
}