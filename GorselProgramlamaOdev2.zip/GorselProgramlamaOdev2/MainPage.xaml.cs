namespace GorselProgramlamaOdev2;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
	}

	private async void NavigateToCreditPage(object sender, EventArgs e)
	{
		await Navigation.PushAsync(new CreditPage());
	}

	private async void NavigateToBMICalculatorPage(object sender, EventArgs e)
	{
		await Navigation.PushAsync(new BMICalculatorPage());
	}

	private async void NavigateToColorPickerPage(object sender, EventArgs e)
	{
		await Navigation.PushAsync(new ColorPickerPage());
	}
}